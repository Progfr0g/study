package ru.sfedu.photosearch.utils;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class XML_utilTest {

    @Test
    void createFiles() {
        XML_util.createFiles();
    }
}