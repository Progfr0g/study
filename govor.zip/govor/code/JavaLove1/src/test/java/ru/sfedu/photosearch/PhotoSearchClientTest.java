package ru.sfedu.photosearch;

import org.junit.jupiter.api.Test;

class PhotoSearchClientTest {
    @Test
    void logBasicSystemInfo() {
//        PhotoSearchClient search_client = new PhotoSearchClient();
//        search_client.logBasicSystemInfo();
    }
}

