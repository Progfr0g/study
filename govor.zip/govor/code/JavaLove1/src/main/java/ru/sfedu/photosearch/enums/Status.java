package ru.sfedu.photosearch.enums;

public enum Status {
    UNCOMPLETED,
    COMPLETED,
    APPROVED,
    NONE
}
