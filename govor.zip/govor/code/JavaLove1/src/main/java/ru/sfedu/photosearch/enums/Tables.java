package ru.sfedu.photosearch.enums;

public enum Tables {
    USERS,
    EVENTS,
    PHOTOS,
    COMMENTS,
    RATES
}
