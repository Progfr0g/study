package ru.sfedu.photosearch.enums;

public enum PaymentMethod {
    CASH, ONLINE_PAYMENT, NONE
}
