package ru.sfedu.photosearch.enums;

public enum Role {
    CUSTOMER,
    EXECUTOR,
    NONE
}
