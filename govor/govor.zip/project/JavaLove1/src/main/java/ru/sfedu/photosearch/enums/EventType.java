package ru.sfedu.photosearch.enums;

/**
 * Энумератор для указания типа события
 */

public enum EventType {
    OFFER,
    ORDER
}
