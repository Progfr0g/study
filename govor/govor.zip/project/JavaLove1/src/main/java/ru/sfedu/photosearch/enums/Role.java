package ru.sfedu.photosearch.enums;

/**
 * Энумератор для указания роли пользователя
 */

public enum Role {
    CUSTOMER,
    PHOTOGRAPHER,
    NONE
}
